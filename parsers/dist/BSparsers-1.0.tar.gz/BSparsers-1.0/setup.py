from distutils.core import setup
setup(name='BSparsers',
      version='1.0',
      py_modules=['parsers'],
      author='Ben Schneider',
      author_email=' ')
